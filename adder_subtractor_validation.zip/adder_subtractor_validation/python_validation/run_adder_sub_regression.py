# run_adder_sub_regression.py
# Simplified regression test runner for 5 addition and 5 subtraction tests using YAML test vectors.

import os
import sys
import argparse
import time
import yaml

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from serial_driver import SerialDriver
from report_generator import ReportGenerator

def run_regression(port):
    print("==================================================")
    print("STARTING 8-BIT ADDER/SUBTRACTOR SIMPLIFIED REGRESSION")
    print("==================================================")
    print(f"Port:       {port}")
    print("--------------------------------------------------")
    
    # Load test vectors and protocol specification from YAML
    yaml_path = os.path.join(os.path.dirname(__file__), 'register_model.yaml')
    print(f"Loading register model and test vectors from: {yaml_path}")
    with open(yaml_path, 'r') as f:
        model = yaml.safe_load(f)
        
    tests = model['test_vectors']
    print(f"Loaded {len(tests)} test vectors successfully.")
    print("--------------------------------------------------")
    
    driver = SerialDriver(port=port, baudrate=115200)
    if not driver.open():
        sys.exit(1)
        
    test_results = []

    for i, tc in enumerate(tests):
        tc_num = i + 1
        name = f"TC-{tc_num:02d}: {tc['type']} ({tc['a']} {'+' if tc['ctrl']==0 else '-'} {tc['b']})"
        print(f"Running {name}...")
        start_time = time.time()
        
        # Send 3 bytes: [A, B, CTRL]
        resp = driver.write_packet(bytes([tc['a'], tc['b'], tc['ctrl']]))
        duration = time.time() - start_time
        
        if len(resp) < 2:
            status = "FAILED"
            notes = f"Timeout: Received {len(resp)} bytes, expected 2."
            actual_res, actual_cb = 0, 0
        else:
            actual_res = resp[0]
            actual_cb = resp[1]
            
            passed = (actual_res == tc['exp_res']) and (actual_cb == tc['exp_cb'])
            status = "PASSED" if passed else "FAILED"
            
            op_symbol = "+" if tc['ctrl'] == 0 else "-"
            cb_label = "Carry" if tc['ctrl'] == 0 else "Borrow"
            
            notes = (
                f"<b>Inputs:</b> A = {tc['a']}, B = {tc['b']}, CTRL = {tc['ctrl']} ({tc['type']})<br/>"
                f"<b>Expected:</b> {tc['a']} {op_symbol} {tc['b']} = {tc['exp_res']} ({cb_label}: {tc['exp_cb']})<br/>"
                f"<b>Actual:</b> {tc['a']} {op_symbol} {tc['b']} = {actual_res} ({cb_label}: {actual_cb})"
            )
            
        test_results.append({
            "name": name,
            "description": tc['desc'],
            "status": status,
            "duration": duration,
            "notes": notes
        })
        
        print(f"Result:  {status} ({duration:.4f}s)")
        print(f"Details: {tc['a']} {'+' if tc['ctrl']==0 else '-'} {tc['b']} | Expected: {tc['exp_res']} (C/B:{tc['exp_cb']}), Got: {actual_res} (C/B:{actual_cb})")
        print("--------------------------------------------------")

    driver.close()
    
    # Generate HTML Report
    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    html_report_path = os.path.join(parent_dir, 'report.html')
    
    print("Generating validation reports...")
    rep_gen = ReportGenerator(test_results)
    rep_gen.generate_html(html_report_path)
    
    print("==================================================")
    print("REGRESSION COMPLETED SUMMARY")
    print("==================================================")
    print(f"Tests Run:  {len(test_results)}")
    print(f"Passed:     {sum(1 for t in test_results if t['status'] == 'PASSED')} / {len(test_results)}")
    print(f"Reports saved in: {parent_dir}")
    print("==================================================")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=str, default='MOCK', help='Serial port (e.g. COM7 or MOCK)')
    args = parser.parse_args()
    
    run_regression(args.port)
